<div class="container-fluid">
  <h3><?= $title ?></h3>
  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          <h4>Menu Management</h4>
        </div>
        <div class="card-body">
          <button class="btn btn-success btn-sm mb-3" data-toggle="modal" data-target="#addMenu">Tambah Menu</button>
          <div class="table-responsive">
            <table class="table table-bordered table-hover" id="table">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Interface</th>
                  <th>Title</th>
                  <th>Link</th>
                  <th>Icon</th>
                  <th>Status</th>
                  <th>Sub Menu</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              <?php
                  $index = 1;
                  foreach ($list_menu_all as $item) {
                    echo "<tr>";
                    echo "<td>$index</td>";
                    echo "<td>$item->interface_judul</td>";
                    echo "<td>$item->menu_title</td>";
                    echo "<td>$item->menu_link</td>";
                    echo "<td>$item->menu_icon</td>";
                    if ($item->active == 1) {
                      echo "<td><span class='badge badge-success'>Active</span></td>";
                    } else {
                      echo "<td><span class='badge badge-danger'>Non Active</span></td>";
                    }
                    if ($item->sub_menu == 1) {
                      echo "<td><span class='badge badge-success'>Yes</span></td>";
                    } else {
                      echo "<td><span class='badge badge-danger'>No</span></td>";
                    }
                    echo "<td>";
                    echo "<button class='btn btn-primary btn-sm m-2' data-toggle='modal' data-target='#editMenu' onclick=\"getMenu('".encrypt_url($item->menu_id)."')\"><i class='fas fa-edit fa-sm'></i></button>";
                    echo "<button class='btn btn-danger btn-sm m-2' onclick=\"promptDelete('".base_url("delete_menu?id=".encrypt_url($item->menu_id))."')\"><i class='fas fa-trash fa-sm'></i></button>";
                    echo "</td>";
                    echo "</tr>";
                    $index++;
                  }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- The Modal -->
<div class="modal fade" id="addMenu">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Menu</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <?= form_open("add_menu"); ?>
        <div class="form-group">
          <label>Interface</label>
          <select name="interface_id" class="form-control">
            <option selected disabled>-- Pilih Interface --</option>
            <?php
              foreach ($list_interface_all as $item) {
                echo "<option value='$item->interface_id'>$item->interface_judul</option>";
              }
            ?>
          </select>
        </div>
        <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-control" placeholder="Masukan title menu..." name="menu_title">
        </div>
        <div class="form-group">
          <label>Judul</label>
          <input type="text" class="form-control" placeholder="Masukan judul menu..." name="menu_judul">
        </div>
        <div class="form-group">
          <label>Link</label>
          <input type="text" class="form-control" placeholder="Masukan link menu..." name="menu_link">
        </div>
        <div class="form-group">
          <label>Icon</label>
          <input type="text" class="form-control" placeholder="Masukan icon menu..." name="menu_icon">
        </div>
        <div class="form-group">
          <label>Active</label>
          <select name="active" class="form-control">
              <option value="1">Active</option>
              <option value="0">No Active</option>
          </select>
        </div>
        <div class="form-group">
          <label>Add Submenu?</label>
          <select name="sub_menu" class="form-control">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select>
        </div>
        <input type="submit" class="btn btn-success btn-sm" value="Simpan">
        <?= form_close(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="editMenu">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Menu</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <?= form_open("edit_menu"); ?>
        <div class="form-group">
          <label>Interface</label>
          <input type="hidden" name="menu_id" id="menuId">
          <select name="interface_id" class="form-control" id="interfaceId">
          </select>
        </div>
        <div class="form-group">
          <label>Title</label>
          <input type="text" class="form-control" id="menuTitle" placeholder="Masukan title menu..." name="menu_title">
        </div>
        <div class="form-group">
          <label>Judul</label>
          <input type="text" class="form-control" id="menuJudul" placeholder="Masukan judul menu..." name="menu_judul">
        </div>
        <div class="form-group">
          <label>Link</label>
          <input type="text" class="form-control" id="menuLink" placeholder="Masukan link menu..." name="menu_link">
        </div>
        <div class="form-group">
          <label>Icon</label>
          <input type="text" class="form-control" id="menuIcon" placeholder="Masukan icon menu..." name="menu_icon">
        </div>
        <div class="form-group">
          <label>Active</label>
          <select name="active" class="form-control" id="active">
          </select>
        </div>
        <div class="form-group">
          <label>Add Submenu?</label>
          <select name="sub_menu" class="form-control" id="subMenu">
          </select>
        </div>
        <input type="submit" class="btn btn-success btn-sm" value="Simpan">
        <?= form_close(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
  function getMenu(id) {
    $.ajax({
      url: "<?= base_url("get_admin") ?>?id="+id,
      type: "GET",
      cache: false,
      success: function(result) {
        let hasil = JSON.parse(result);
        $("#menuId").val(hasil.data.menu_id);
        $("#interfaceId").html(hasil.interface);
        $("#menuTitle").val(hasil.data.menu_title);
        $("#menuJudul").val(hasil.data.menu_judul);
        $("#menuLink").val(hasil.data.menu_link);
        $("#menuIcon").val(hasil.data.menu_icon);
        $("#active").html(hasil.active);
        $("#subMenu").html(hasil.sub);
      }
    })
  }
</script>