<div class="container-fluid">
<?= $breadcrumb; ?>
  <div class="card">
    <div class="card-body">
      <h2>Body</h2>
    </div>
  </div>
</div>