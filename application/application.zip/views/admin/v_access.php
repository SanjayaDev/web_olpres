<div class="container-fluid">
  <h3><?= $title; ?></h3>
  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <h5>Interface Management</h5>
          <button class="btn btn-success btn-sm mb-3" data-toggle="modal" data-target="#addInterface">Add Interface</button>
          <div class="table-responsive">
            <table class="table table-bordered table-hover" id="table">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Interface</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $index = 1;
                foreach ($interface as $item) {
                  echo "<tr>";
                  echo "<td>$index</td>";
                  echo "<td>$item->interface_judul</td>";
                  echo "<td>";
                  echo "<button data-toggle='modal' data-target='#editInterface' onclick='editInterface($item->interface_id)' class='btn btn-outline-info btn-sm m-1' tooltip='true' title='Edit'><i class='fas fa-edit'></i></button>";
                  echo "<button onclick=\"promptDelete('" . base_url("delete_interface?id=$item->interface_id") . "')\" class='btn btn-outline-danger btn-sm m-1' tooltip='true' title='Delete'><i class='fas fa-trash'></i></button>";
                  echo "</td>";
                  echo "</tr>";
                  $index++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <h5>Access Control</h5>
          <button class="btn btn-success btn-sm mb-3" data-toggle="modal" data-target="#addAccess">Add Access</button>
          <div class="table-responsive">
            <table class="table table-bordered table-hover" id="table2">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Divisi</th>
                  <th>Role</th>
                  <th>Interface</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $index = 1;
                foreach ($list_access as $item) {
                  echo "<tr>";
                  echo "<td>$index</td>";
                  echo "<td>$item->divisi</td>";
                  echo "<td>$item->role</td>";
                  echo "<td>$item->interface_judul</td>";
                  echo "<td>";
                  echo "<button class='btn btn-outline-info btn-sm m-1' tooltip='true' title='Edit' data-toggle='modal' data-target='#editAccess' onclick='editAccess($item->rel_id)'><i class='fas fa-edit'></i></button>";
                  echo "<button onclick=\"promptDelete('" . base_url("delete_access?id=$item->rel_id") . "')\" class='btn btn-outline-danger btn-sm m-1' tooltip='true' title='Delete'><i class='fas fa-trash'></i></button>";
                  echo "</td>";
                  echo "</tr>";
                  $index++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Menu -->
<?= form_open("add_interface"); ?>
<div class="modal fade" id="addInterface">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Interface</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <?= form_label("Interface"); ?>
          <?= form_input("interface_judul", "", "class='form-control' placeholder='Masukan nama interface...' required") ?>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success btn-sm">Add Interface</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?= form_close(); ?>

<?= form_open("edit_interface"); ?>
<div class="modal fade" id="editInterface">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Interface</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <?= form_label("Interface"); ?>
          <?= form_input("interface_judul", "", "class='form-control' id='interfaceJudul' placeholder='Masukan nama interface...' required") ?>
          <?= form_hidden("interface_id", "") ?>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success btn-sm">Edit Interface</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?= form_close(); ?>


<?= form_open("add_access"); ?>
<div class="modal fade" id="addAccess">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Access</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <?= form_label("Interface"); ?>
          <select name="interface_id" class="form-control">
            <?php
            foreach ($interface as $item) {
              echo "<option value='$item->interface_id'>$item->interface_judul</option>";
            }
            ?>
          </select>
        </div>
        <div class="form-group">
          <?= form_label("Role"); ?>
          <select name="role_id" class="form-control">
            <?php
            foreach ($list_role as $item) {
              echo "<option value='$item->role_id'>$item->role</option>";
            }
            ?>
          </select>
        </div>
        <div class="form-group">
          <?= form_label("Divisi"); ?>
          <select name="divisi_id" class="form-control">
            <?php
            foreach ($list_divisi as $item) {
              echo "<option value='$item->divisi_id'>$item->divisi</option>";
            }
            ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success btn-sm">Add Access</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?= form_close(); ?>

<?= form_open("edit_access"); ?>
<div class="modal fade" id="editAccess">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Access</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <?= form_label("Interface"); ?>
          <select name="interface_id" class="form-control" id="interface">
          </select>
        </div>
        <div class="form-group">
          <?= form_label("Role"); ?>
          <select name="role_id" class="form-control" id="role">
          </select>
        </div>
        <div class="form-group">
          <?= form_label("Divisi"); ?>
          <select name="divisi_id" class="form-control" id="divisi">
          </select>
        </div>
        <input type="hidden" name="rel_id" id="relId">
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success btn-sm">Edit Access</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?= form_close(); ?>


<script>
  function editInterface(id) {
    $.ajax({
      url: "<?= base_url("get_interface") ?>",
      cache: false,
      dataType: "JSON",
      type: "POST",
      data: {
        interface_id: id,
        <?= $this->security->get_csrf_token_name(); ?>: "<?= $this->security->get_csrf_hash(); ?>"
      },
      success: function(result) {
        $("#interfaceJudul").val(result.data.interface_judul);
        $("[name='interface_id']").val(result.data.interface_id);
        // console.log(result.data.interface_id);
      }
    })
  }

  function editAccess(id) {
    $.ajax({
      url: "<?= base_url("get_access") ?>",
      cache: false,
      dataType: "JSON",
      type: "POST",
      data: {
        rel_id: id,
        <?= $this->security->get_csrf_token_name(); ?>: "<?= $this->security->get_csrf_hash(); ?>"
      },
      success: function(result) {
        $("#interface").html(result.interface);
        $("#role").html(result.role);
        $("#divisi").html(result.divisi);
        $("#relId").val(result.rel_id);
      }
    })
  }
</script>