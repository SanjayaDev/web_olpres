<div class="container-fluid">
  <div class="card">
    <div class="card-body">
      <h3 class="text-center">You don't allowed access!</h3>
    </div>
  </div>
</div>