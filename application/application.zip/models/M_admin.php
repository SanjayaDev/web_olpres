<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model {

  public function get_interface_listed()
  {
    $query = $this->db->select("*")
                      ->from("`list_interface` li")
                      ->get();
    if ($query) {
      return $query->result();
    } else {
      return FALSE;
    }
  }

  public function get_menu_all()
  {
    $query = $this->db->select("lm.*, li.`interface_judul`")
                      ->from("`list_menu` lm")
                      ->join("list_interface li", "li.`interface_id` = lm.`interface_id`")
                      ->get();
    if ($query) {
      return $query->result();
    } else {
      return FALSE;
    }
  }

  public function get_access_control_list()
  {
    $query = $this->db->select("ld.`divisi`, lr.`role`, li.`interface_judul`, rma.`rel_id`")
                      ->from("`rel_menu_admin` rma")
                      ->join("`list_divisi` ld", "ld.`divisi_id` = rma.`divisi_id`")
                      ->join("`list_role` lr", "lr.`role_id` = rma.`role_id`")
                      ->join("`list_interface` li", "li.`interface_id` = rma.`interface_id`")
                      ->get();
    if ($query) {
      return $query->result();
    } else {
      return FALSE;
    }
  }

  public function add_interface($interface_judul)
  {
    $response = new stdClass();
    $data = ["interface_judul" => $interface_judul];
    $query = $this->db->insert("list_interface", $data);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Success add interface!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function get_interface_detail($id)
  {
    $response = new stdClass();
    $query = $this->db->select("*")
                      ->from("`list_interface` li")
                      ->where("interface_id", $id)
                      ->get();
    if ($query) {
      $response->success = 200;
      $response->data = $query->row();
    } else {
      $response->success = 201;
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function edit_interface($input)
  {
    $response = new stdClass();
    $data = ["interface_judul" => $this->db->escape_str($input->interface_judul)];
    $where = ["interface_id" => $this->db->escape_str($input->interface_id)];

    $query = $this->db->update("list_interface", $data, $where);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Success edited interface!";
      // $response->debug = $this->db->last_query();
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function delete_interface($id)
  {
    $response = new stdClass();
    $where = ["interface_id" => $this->db->escape_str($id)];

    $query = $this->db->delete("list_interface", $where);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Success deleted interface!";
      // $response->debug = $this->db->last_query();
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function get_role_listed()
  {
    $query = $this->db->get("list_role");
    if ($query) {
      return $query->result();
    } else {
      return FALSE;
    }
  }

  public function get_divisi_listed()
  {
    $query = $this->db->get("list_divisi");
    if ($query) {
      return $query->result();
    } else {
      return FALSE;
    }
  }

  public function add_access($input)
  {
    $response = new stdClass();
    $data = [
      "interface_id" => $this->db->escape_str($input->interface_id),
      "role_id" => $this->db->escape_str($input->role_id),
      "divisi_id" => $this->db->escape_str($input->divisi_id)
    ];
    $query = $this->db->insert("rel_menu_admin", $data);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Success add access!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function get_access_detail($rel_id)
  {
    $response = new stdClass();
    $query = $this->db->get_where("rel_menu_admin", ["rel_id" => $rel_id]);
    if ($query) {
      $data = $query->row();
      $response->rel_id = $data->rel_id;
      $interafe = $this->get_interface_listed();
      $response->interface = "";
      foreach ($interafe as $item) {
        if ($item->interface_id == $data->interface_id) {
          $response->interface .= "<option selected value='$item->interface_id'>$item->interface_judul</option>";
        } else {
          $response->interface .= "<option value='$item->interface_id'>$item->interface_judul</option>";
        }
      }
      $list_role = $this->get_role_listed();
      $response->role = "";
      foreach ($list_role as $item) {
        if ($item->role_id == $data->role_id) {
          $response->role .= "<option selected value='$item->role_id'>$item->role</option>";
        } else {
          $response->role .= "<option value='$item->role_id'>$item->role</option>";
        }
      }
      $list_divisi = $this->get_divisi_listed();
      $response->divisi = "";
      foreach ($list_divisi as $item) {
        if ($item->divisi_id == $data->divisi_id) {
          $response->divisi .= "<option selected value='$item->divisi_id'>$item->divisi</option>";
        } else {
          $response->divisi .= "<option value='$item->divisi_id'>$item->divisi</option>";
        }
      }
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function edit_access($input)
  {
    $response = new stdClass();
    $data = [
      "interface_id" => $this->db->escape_str($input->interface_id),
      "role_id" => $this->db->escape_str($input->role_id),
      "divisi_id" => $this->db->escape_str($input->divisi_id)
    ];
    $query = $this->db->update("rel_menu_admin", $data, ["rel_id" => $input->rel_id]);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Success update access!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function delete_access($rel_id)
  {
    $response = new stdClass();
    $query = $this->db->delete("rel_menu_admin", ["rel_id" => $rel_id]);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Success deleted access!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function add_admin($input)
  {
    $response = new stdClass();
    $data = [
      "interface_id" => $this->db->escape_str($input->interface_id),
      "menu_title" => $this->db->escape_str($input->menu_title),
      "menu_judul" => $this->db->escape_str($input->menu_judul),
      "menu_link" => $this->db->escape_str($input->menu_link),
      "menu_icon" => $this->db->escape_str($input->menu_icon),
      "active" => $this->db->escape_str($input->active),
      "sub_menu" => $this->db->escape_str($input->sub_menu)
    ];
    $query = $this->db->insert("list_menu", $data);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Sukses menambahkan menu!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function get_menu_detail($id)
  {
    $response = new stdClass();
    $query = $this->db->select("*")
                      ->from("list_menu")
                      ->where("menu_id", $id)
                      ->get();
    if ($query) {
      $response->data = $query->row();
      $query2 = $this->get_interface_listed();
      if ($query2) {
        $response->interface = "<option>-- Pilih Interface --</option>";
        foreach ($query2 as $item) {
          if ($query->row()->interface_id == $item->interface_id) {
            $response->interface .= "<option selected value='$item->interface_id'>$item->interface_judul</option>";
          } else {
            "<option value='$item->interface_id'>$item->interface_judul</option>";
          }
        }
        $response->active = "";
        if ($query->row()->active == 1) {
          $response->active .= "<option selected value='1'>Active</option>";
          $response->active .= "<option value='0'>No Active</option>";
        } else {
          $response->active .= "<option value='1'>Active</option>";
          $response->active .= "<option selected value='0'>No Active</option>";
        }
        $response->sub = "";
        if ($query->row()->sub_menu == 1) {
          $response->sub .= "<option selected value='1'>Yes</option>";
          $response->sub .= "<option value='0'>No</option>";
        } else {
          $response->sub .= "<option value='1'>Yes</option>";
          $response->sub .= "<option selected value='0'>No</option>";
        }
      } else {
        $response->message = "Query 2 failed";
      }
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function edit_menu($input)
  {
    $response = new stdClass();
    $id = ["menu_id" => $this->db->escape_str($input->menu_id)];
    $data = [
      "interface_id" => $this->db->escape_str($input->interface_id),
      "menu_title" => $this->db->escape_str($input->menu_title),
      "menu_judul" => $this->db->escape_str($input->menu_judul),
      "menu_link" => $this->db->escape_str($input->menu_link),
      "menu_icon" => $this->db->escape_str($input->menu_icon),
      "active" => $this->db->escape_str($input->active),
      "sub_menu" => $this->db->escape_str($input->sub_menu)
    ];
    $query = $this->db->update("list_menu", $data, $id);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Sukses ubah data menu!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }

  public function delete_menu($id)
  {
    $response = new stdClass();
    $query = $this->db->delete("list_menu", ["menu_id" => $id]);
    if ($query) {
      $response->success = TRUE;
      $response->message = "Berhasil menghapus menu!";
    } else {
      $response->message = "Query failed!";
    }
    return $response;
  }
}