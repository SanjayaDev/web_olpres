<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Super_admin extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->model("M_admin");
    $this->addon->login_security();
  }

  public function index()
  {
    $data = [
      "title" => "Dashboard",
      "content" => "admin/v_dashboard",
      "list_interface" => $this->M_data->get_interface(),
      "list_menu" => $this->M_data->get_menu(),
      "list_sub" => $this->M_data->get_sub()
    ];
    $this->load->view("layout/admin_content", $data);
  }

  public function view_access_management()
  {
    $data = [
      "title" => "Access Management",
      "content" => "admin/v_dashboard",
      "list_interface" => $this->M_data->get_interface(),
      "list_menu" => $this->M_data->get_menu(),
      "list_sub" => $this->M_data->get_sub(),
      "list_access" => $this->M_admin->get_access_control_list(),
      "interface" => $this->M_admin->get_interface_listed(), 
      "list_role" => $this->M_admin->get_role_listed(),
      "list_divisi" => $this->M_admin->get_divisi_listed()
    ];
    $data["content"] = "admin/v_access";
    $this->load->view("layout/admin_content", $data);
  }

  public function validate_interface_add()
  {
    $this->form_validation->set_rules('interface_judul', 'Interface', 'required');
    
    if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "Isi form dengan benar!")</script>');
      redirect("access");
    } else {
      $this->process_interface_add();
    }    
  }

  private function process_interface_add()
  {
    $interface_judul = html_escape($this->input->post("interface_judul", TRUE));
    $check = $this->M_admin->add_interface($interface_judul);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "'.$check->message.'")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Gagal!", "'.$check->message.'")</script>');
    }
    redirect("access");
  }

  public function get_interface()
  {
    $interface_id = html_escape($this->input->post("interface_id", TRUE));
    $check = $this->M_admin->get_interface_detail($interface_id);
    echo json_encode($check);
  }

  public function validate_interface_edit()
  {
    $this->form_validation->set_rules('interface_judul', 'Interface', 'required');
    $this->form_validation->set_rules('interface_id', 'Interface', 'required');

    if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "Isi form dengan benar!")</script>');
      redirect("access");
    } else {
      $this->process_interface_edit();
    }
  }

  private function process_interface_edit()
  {
    $input = (object)html_escape($this->input->post());
    $check = $this->M_admin->edit_interface($input);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Gagal!", "' . $check->message . '")</script>');
    }
    // var_dump($check);
    redirect("access");
  }

  public function process_interface_delete()
  {
    $id = html_escape($this->input->get("id", TRUE));
    $check = $this->M_admin->delete_interface($id);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Gagal!", "' . $check->message . '")</script>');
    }    
    // var_dump($check);
    redirect("access");
  }  

  public function validate_access_add()
  {
    $this->form_validation->set_rules('interface_id', 'Access', 'required|numeric');
    $this->form_validation->set_rules('role_id', 'Access', 'required|numeric');
    $this->form_validation->set_rules('divisi_id', 'Access', 'required|numeric');

    if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "Isi form dengan benar!")</script>');
      redirect("access");
    } else {
      $this->process_access_add();
    }
  }

  private function process_access_add()
  {
    $input = (object)html_escape($this->input->post());
    $check = $this->M_admin->add_access($input);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Gagal!", "' . $check->message . '")</script>');
    }
    redirect("access");
  }

  public function get_access()
  {
    $rel_id = html_escape($this->input->post("rel_id", TRUE));
    $check = $this->M_admin->get_access_detail($rel_id);
    echo json_encode($check);    
  }

  public function validate_access_edit()
  {
    $this->form_validation->set_rules('interface_id', 'Access', 'required|numeric');
    $this->form_validation->set_rules('role_id', 'Access', 'required|numeric');
    $this->form_validation->set_rules('divisi_id', 'Access', 'required|numeric');
    $this->form_validation->set_rules('rel_id', 'Access', 'required|numeric');
    

    if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "Isi form dengan benar!")</script>');
      redirect("access");
    } else {
      $this->process_access_edit();
    }
  }

  private function process_access_edit()
  {
    $input = (object)html_escape($this->input->post());
    $check = $this->M_admin->edit_access($input);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Gagal!", "' . $check->message . '")</script>');
    }
    redirect("access");
  }

  public function process_access_delete()
  {
    $rel_id = html_escape($this->input->get("id", TRUE));
    $check = $this->M_admin->delete_access($rel_id);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "' . $check->message . '")</script>');
    }
    redirect("access");
  }

  public function view_menu_management()
  {
    $data = [
      "title" => "Menu Management",
      "content" => "admin/v_menu",
      "list_interface" => $this->M_data->get_interface(),
      "list_menu" => $this->M_data->get_menu(),
      "list_sub" => $this->M_data->get_sub(),
      "list_interface_all" => $this->M_data->get_interface_all(),
      "list_menu_all" => $this->M_admin->get_menu_all()
    ];
    $this->load->view("layout/admin_content", $data);
  }

  public function validate_menu_add()
  {
    $this->form_validation->set_rules('interface_id', 'Menu', 'required|numeric');
    $this->form_validation->set_rules('menu_title', 'Menu', 'required');
    $this->form_validation->set_rules('menu_judul', 'Menu', 'required');
    $this->form_validation->set_rules('menu_link', 'Menu', 'required');
    $this->form_validation->set_rules('menu_icon', 'Menu', 'required');
    $this->form_validation->set_rules('active', 'Menu', 'required|numeric');
    $this->form_validation->set_rules('sub_menu', 'Menu', 'required|numeric');

    if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "Gagal! Isi data dengan benar!")</script>');
      redirect("menu");
    } else {
      $this->process_menu_add();
    }
  }

  private function process_menu_add()
  {
    $input = (object)html_escape($this->input->post());
    $check = $this->M_admin->add_admin($input);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "' . $check->message . '")</script>');
    }
    redirect("menu");
  }

  public function get_admin_detail()
  {
    $id = decrypt_url(html_escape($this->input->get("id")));
    $check = $this->M_admin->get_menu_detail($id);
    echo json_encode($check);
  }

  public function validate_menu_edit()
  {
    $this->form_validation->set_rules('menu_id', 'Menu', 'required|numeric');
    $this->form_validation->set_rules('interface_id', 'Menu', 'required|numeric');
    $this->form_validation->set_rules('menu_title', 'Menu', 'required');
    $this->form_validation->set_rules('menu_judul', 'Menu', 'required');
    $this->form_validation->set_rules('menu_link', 'Menu', 'required');
    $this->form_validation->set_rules('menu_icon', 'Menu', 'required');
    $this->form_validation->set_rules('active', 'Menu', 'required|numeric');
    $this->form_validation->set_rules('sub_menu', 'Menu', 'required|numeric');

    if ($this->form_validation->run() == FALSE) {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "Gagal! Isi data dengan benar!")</script>');
      redirect("menu");
    } else {
      $this->process_menu_edit();
    }
  }

  public function process_menu_edit()
  {
    $input = (object)html_escape($this->input->post());
    $check = $this->M_admin->edit_menu($input);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("error", "Gagal!", "' . $check->message . '")</script>');
    }
    redirect("menu");
  }

  public function process_menu_delete()
  {
    $id = decrypt_url(html_escape($this->input->get("id")));
    $check = $this->M_admin->delete_menu($id);
    if ($check->success === TRUE) {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Sukses!", "' . $check->message . '")</script>');
    } else {
      $this->session->set_flashdata('pesan', '<script>sweet("success", "Gagal!", "' . $check->message . '")</script>');
    }
    redirect("menu");
  }
}